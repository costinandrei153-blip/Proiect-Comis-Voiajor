#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# standard python imports

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

